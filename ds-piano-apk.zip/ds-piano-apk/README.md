# DS Piano - Crear el APK con GitHub

## Archivos de este proyecto
- `www/index.html` -> la aplicacion (el piano)
- `package.json` y `capacitor.config.json` -> configuracion de la app
- `make_icons.py` -> crea el icono de la app automaticamente
- `.github/workflows/build-apk.yml` -> la "fabrica" que crea el APK (copia visible: `COPIA-build-apk.yml`)

## Pasos (desde computadora o desde el navegador del celular)
1. Entra a https://github.com y crea una cuenta (o inicia sesion).
2. Toca **+** > **New repository**. Nombre: `ds-piano`. Marca **Public**. Pulsa **Create repository**.
3. Sube los archivos (elige UN metodo):
   - **Metodo A (computadora):** descomprime el ZIP, abre la carpeta, en el repo pulsa **uploading an existing file**, arrastra TODO el contenido de la carpeta (incluida la carpeta oculta `.github`) y pulsa **Commit changes**.
   - **Metodo B (celular o si no se subio `.github`):** en el repo pulsa **Add file > Create new file**. En el nombre escribe la ruta exacta (con las barras), pega el contenido del archivo y pulsa **Commit changes**. Repite para cada archivo:
     `package.json`, `capacitor.config.json`, `make_icons.py`, `www/index.html`, `.github/workflows/build-apk.yml`
4. Abre la pestana **Actions**. Si pide permiso, pulsa **I understand my workflows, go ahead and enable them**.
5. Si no empezo solo: **Crear APK** > **Run workflow** > **Run workflow**.
6. Espera 5 a 10 minutos hasta ver el circulo verde.
7. Descarga: en la pagina principal del repo, columna derecha, **Releases** > la version mas reciente > **DS-Piano.apk**.
8. Instala en el telefono Android: abre el APK, permite **instalar apps de esta fuente** y, si sale aviso de Play Protect, pulsa **Instalar de todos modos**.

## Actualizar la app
Edita `www/index.html` en GitHub (icono del lapiz), pulsa **Commit changes** y en unos minutos habra un APK nuevo en Releases.

## Si falla (X roja)
Entra al intento fallido en Actions, abre el paso marcado en rojo y copia el error.
